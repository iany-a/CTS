public interface IHotelAreaManager {
    String getAreaName();
    void coordinateArea();
}